package ch.hslu.cobau.vsl2.ast;

public interface Assignable {
    void accept(Visitor visitor);
}

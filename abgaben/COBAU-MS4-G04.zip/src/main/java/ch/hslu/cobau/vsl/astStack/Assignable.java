package ch.hslu.cobau.vsl.astStack;

public interface Assignable {
    void accept(Visitor visitor);
}

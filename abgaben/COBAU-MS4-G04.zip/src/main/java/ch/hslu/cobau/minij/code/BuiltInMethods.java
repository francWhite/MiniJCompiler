package ch.hslu.cobau.minij.code;

public enum BuiltInMethods {
    writeInt,
    writeChar,
    readInt,
    readChar
}

package ch.hslu.cobau.lectureExample;

public abstract class Expression implements Visitable {
}

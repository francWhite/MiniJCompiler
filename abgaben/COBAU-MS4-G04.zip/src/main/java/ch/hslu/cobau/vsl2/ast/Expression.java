package ch.hslu.cobau.vsl2.ast;

public abstract class Expression implements Visitable, Assignable {

}

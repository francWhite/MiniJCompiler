package ch.hslu.cobau.minij.ast.statement;

import ch.hslu.cobau.minij.ast.AstElement;

public abstract class Statement extends AstElement {
}

package ch.hslu.cobau.vsl.astNoStack;

public abstract class Expression implements Visitable, Assignable {
}

package ch.hslu.cobau.minij.ast.constants;

import ch.hslu.cobau.minij.ast.expression.Expression;

public abstract class Constant extends Expression {
}

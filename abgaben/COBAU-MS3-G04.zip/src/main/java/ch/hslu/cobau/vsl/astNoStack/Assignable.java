package ch.hslu.cobau.vsl.astNoStack;

public interface Assignable {
    Object accept(Visitor visitor);
}

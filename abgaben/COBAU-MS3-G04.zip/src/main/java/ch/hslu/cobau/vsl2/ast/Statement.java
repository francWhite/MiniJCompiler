package ch.hslu.cobau.vsl2.ast;

public abstract class Statement implements Visitable {
}

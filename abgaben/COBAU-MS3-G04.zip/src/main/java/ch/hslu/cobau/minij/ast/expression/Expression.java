package ch.hslu.cobau.minij.ast.expression;

import ch.hslu.cobau.minij.ast.AstElement;

public abstract class Expression extends AstElement {
}

package ch.hslu.cobau.minij.ast.expression;

public enum UnaryOperator {
    MINUS,
    NOT,
    PRE_INCREMENT,
    POST_INCREMENT,
    PRE_DECREMENT,
    POST_DECREMENT,
}

package ch.hslu.cobau.minij.ast.expression;

public abstract class MemoryAccess extends Expression {
}

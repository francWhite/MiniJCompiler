package ch.hslu.cobau.minij.ast.type;

public class Type {
}

package ch.hslu.cobau.vsl.astStack;

public abstract class Expression implements Visitable, Assignable {

}
